# src/main.py
import os
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

def main():
    print("🚀 Running Market Segmentation Project")

    # Load dataset (update filename if you changed it)
    data_path = "data/rfm_raw_auto.csv"
    df = pd.read_csv(data_path)
    print("📊 Dataset Head:")
    print(df.head())

    # Ensure reports folder exists
    os.makedirs("reports", exist_ok=True)

    # --- Inspect numeric vs non-numeric columns ---
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    non_numeric_cols = df.select_dtypes(exclude=[np.number]).columns.tolist()

    print("\n🔢 Numeric columns:", numeric_cols)
    print("🔤 Non-numeric columns:", non_numeric_cols)

    if len(numeric_cols) == 0:
        raise RuntimeError("No numeric columns found. Either convert columns to numbers or pick numeric features.")

    # --- Basic preprocessing for numeric features ---
    X_num = df[numeric_cols].copy()

    # Fill numeric NaNs with median (simple and safe)
    X_num = X_num.fillna(X_num.median())

    # If you want to include categorical data (like 'Country') you can uncomment and use get_dummies:
    # WARNING: one-hot can create many columns; consider selecting top-k categories first.
    #cat_cols = ['Country']   # example
    #df_cat = pd.get_dummies(df[cat_cols].fillna('NA'), drop_first=True)
    #X = pd.concat([X_num, df_cat], axis=1)
    # For now we'll only use numeric columns:
    X = X_num.values

    # Scale
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # Clustering
    n_clusters = 4
    kmeans = KMeans(n_clusters=n_clusters, random_state=42)
    labels = kmeans.fit_predict(X_scaled)
    df['cluster'] = labels

    # Save clustered data
    out_csv = "reports/rfm_with_clusters_from_main.csv"
    df.to_csv(out_csv, index=False)
    print(f"\n✅ Saved clustered data to: {out_csv}")

    # Simple 2D plot: use first two numeric features if available
    if X_scaled.shape[1] >= 2:
        x0 = X_scaled[:, 0]
        x1 = X_scaled[:, 1]
    else:
        x0 = X_scaled[:, 0]
        x1 = np.zeros_like(x0)

    plt.figure(figsize=(6,5))
    plt.scatter(x0, x1, c=labels, s=10)
    plt.title("Clusters (first 2 numeric features)")
    plt.xlabel(numeric_cols[0])
    plt.ylabel(numeric_cols[1] if len(numeric_cols) > 1 else "zero")
    plt.tight_layout()
    plot_path = "reports/clusters.png"
    plt.savefig(plot_path)
    plt.close()
    print(f"📁 Saved cluster plot: {plot_path}")

    print("\n🔍 Example cluster counts:")
    print(df['cluster'].value_counts())

if __name__ == "__main__":
    main()
