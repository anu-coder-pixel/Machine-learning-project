# Auto-generated cluster report
Input file: online_retail_II.xlsx
Run time: 2025-11-18T08:39:27.130837

Cluster profile (saved at data/cluster_profile.csv):

FinalCluster,Recency,Frequency,Monetary,Count
0,134.5,1.64,445.83,2439
1,33.76,6.71,2807.2,1800


Figures saved in figures/ folder.
